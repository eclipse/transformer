package 日本語パッケージ;

public class 日本語のJavaクラス {
	public static String hello() {
		return "Hello, World";
	}
}
